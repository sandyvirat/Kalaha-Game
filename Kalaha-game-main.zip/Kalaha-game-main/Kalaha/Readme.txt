we implemented the following features:

* MiniMax algorithm with depth-first search implemented
* Iterative Deepening
* Stops after 5 seconds
* Alpha-Beta Pruning (with move ordering in order to improve pruning)
