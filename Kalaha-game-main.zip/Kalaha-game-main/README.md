# Kalaha Game 


I implemented the following features:

* MiniMax algorithm with depth-first search implemented
* Iterative Deepening
* Time to AI move is 5 seconds
* Alpha-Beta Pruning (with move ordering in order to improve pruning)
* Opening book for choosing the first move
Project in Artificial Intelligence to train the AI agent.
